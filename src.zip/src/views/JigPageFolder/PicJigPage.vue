<template>
  รูปภาพ standard
</template>

<script>
export default {

}
</script>

<style>

</style>